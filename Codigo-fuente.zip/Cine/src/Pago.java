
public class Pago {

	public Double tarjeta = new Double(0);
	public Double efectivo = new Double(0);
	

	public void crearPago() {
		// Start of user code for method crearPago
		// End of user code
	}

	/**
	 * Description of the method eliminarPago.
	 */
	public void eliminarPago() {
		// Start of user code for method eliminarPago
		// End of user code
	}

}